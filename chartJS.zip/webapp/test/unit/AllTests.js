sap.ui.define([
	"Dev/chartJS/test/unit/controller/View1.controller"
], function () {
	"use strict";
});